# Authors: Hamza Tazi Bouardi (htazi@mit.edu), Michael L. Li (mlli@mit.edu)
# Modified: Bernhard Egwolf and Nicanor Austriaco, OP (naustria@providence.edu)
import math
import pandas as pd
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import minimize, differential_evolution, basinhopping, dual_annealing, shgo, brute, fmin
from datetime import datetime, timedelta
from DELPHI_utils import DELPHIDataCreator, DELPHIAggregations, DELPHIDataSaver, get_initial_conditions, mape
import dateutil.parser as dtparser
import os

yesterday = "".join(str(datetime.now().date() - timedelta(days=1)).split("-"))
# TODO: Find a way to make these paths automatic, whoever the user is...
PATH_TO_FOLDER_DANGER_MAP = (
    ""
    # "/Users/hamzatazi/Desktop/MIT/999.1 Research Assistantship/" +
    # "4. COVID19_Global/covid19orc/danger_map"
)
PATH_TO_WEBSITE_PREDICTED = (
    ""
)
#os.chdir(PATH_TO_FOLDER_DANGER_MAP)
#popcountries = pd.read_csv(
#    f"UID_ISO_FIPS_LookUp_Table.csv"
#)
# TODO: Uncomment these and delete the line with pastparameters=None once 1st run in Python is done!
# try:
#     pastparameters = pd.read_csv(
#         f"predicted/Parameters_Global_{yesterday}.csv"    table2+= list_df_global_predictions_since_100_cases[i].to_numpy().tolist()
#     )
# except:
#

# No of increase steps from quarantine R value back to initial R value (steps from 0 to 10).
steps = range(1)

for step in steps:
    for transition2 in [15]:
        # Increase day is the median day of increase, which takes 30 days.
        # That is the increase starts 15 days before and ends 15 days after this day.
        increase_day = datetime(2020, 6, transition2)

        # Increase after quarantine in percent. No increase for 0%, back to pre quarantine level for 100%.
        increase = 0.0
        print("Increase = %f" % (increase))

        pastparameters = None
        # Initalizing lists of the different dataframes that will be concatenated in the end
        list_df_global_predictions_since_today = []
        list_df_global_predictions_since_100_cases = []
        list_df_global_parameters = []  
        
        country = "Philippines"
        province = "Metro Manila"
        continent = "Asia"
        country_sub = country.replace(" ", "_")
        province_sub = province.replace(" ", "_")
        if os.path.exists(f"input/InputData_MetroManila.csv"):
            totalcases = pd.read_csv(
                f"input/InputData_MetroManila.csv"
            )
            # Use established lower/upper bounds
    # Old parameters and bonds
    #        parameter_list = [1, 0, 2, 0.2, 0.05, 3, 3]
    #        bounds_params = (
    #            (0.75, 1.25), (-10, 10), (1, 3), (0.05, 0.5), (0.01, 0.25), (0.1, 10), (0.1, 10)
    #        )
    # Relaxed bonds for distancing_arctan
    #        bounds_params = (
    #            (0.5, 3.0), (-25, 25), (0.1, 10), (0.01, 0.5), (0.01, 0.25), (0.1, 10), (0.1, 10)
    #        )

            # Below are the definitions some of the parameters of the DELPHI model.
            # They could be adjusted to the situation in Metro Manila.
            #
            # IncubeD corresponds to T_i, the median time to leave incubation (assumed to be 5 days).
            # It is used to compute r_i, the rate of infection leaving incubation phase: r_i = log(2)/T_i
            IncubeD = 5
            # RecoverID corresponds to T_ri, the median time to recovery not under hospitalization (assumed to be 10 days).
            # It is used to compute r_ri, the rate of recovery not under hospitalization: r_ri = log(2)/T_ri             
            RecoverID = 10
            # DetectD corresponds to T_d, the median time to detection (assumed to be 2 days).
            # It is used to compute r_d, the rate of detection: r_d = log(2)/T_d
            DetectD = 2
    # Relaxed parameters and bonds for distancing_cspline
            parameter_list = [2.2*(np.log(2)/DetectD), 20, 0.5, 0.2, 0.05, 3, 3]
            bounds_params = (
    #            (0.01, 5), # Free alpha.
                (parameter_list[0] - 0.000000001, parameter_list[0] + 0.000000001), # Fixed alpha.
                (1.0, 30.0),
                (0.01, 0.9),
                (0.01, 0.5),
                (0.01, 0.25),
                (0.1, 10),
                (0.1, 10)
            )
            
            date_day_since100 = pd.to_datetime(totalcases.loc[totalcases.day_since100 == 0, "date"].item())
            day_increase = (increase_day - date_day_since100).days
            print(f"Day of increase of contacts = %f" % (day_increase))
            print("Date of first valid case (more than 100) date_day_since100: " + str(date_day_since100) + "\n")
            validcases = totalcases[totalcases.day_since100 >= 0][
                ["day_since100", "case_cnt", "death_cnt"]
            ].reset_index(drop=True)
            print("Valid cases from input file:")
            print(validcases)
            print("\n" + "Start modeling.\n")

            # Now we start the modeling part:
            if len(validcases) > 7:
                # Below are the definitions some of the parameters of the DELPHI model.
                # They could be adjusted to the situation in Metro Manila.
                #
                # PopulationT = N is the population value for Metro Manila from (retrieved 5/1/2020): https://worldpopulationreview.com/world-cities/manila-population/
                PopulationT = 13923452
                # We do not scale
                N = PopulationT
                # PopulationD contains the time series of the total no. of deaths D(t) (from input file).
                PopulationD = validcases.loc[0, "death_cnt"]
                # PopulationR is an estimate of the time series of the total no. of recoverd people R(t)
                # (5 times no. of deaths, 10 times in Mathematica script). 
                # Factor 5 or 10 seems to be arbitrary. Why should R(t) be proportional to D(t)? Should be compared with actual data.
                PopulationR = validcases.loc[0, "death_cnt"] * 6
                # PopulationI contains the time series of the total no. of cases (from input file).
                PopulationI = validcases.loc[0, "case_cnt"]
                # PopulationCI contains the time series of the no. of people I(t) who are currently infected and contagious. 
                PopulationCI = PopulationI - PopulationD - PopulationR
                """
                Fixed Parameters based on meta-analysis:
                p_h: Hospitalization Percentage
                RecoverHD: Average Days till Recovery
                VentilationD: Number of Days on Ventilation for Ventilated Patients
                maxT: Maximum # of Days Modeled
                p_d: Percentage of True Cases Detected
                p_v: Percentage of Hospitalized Patients Ventilated,
                balance: Ratio of Fitting between cases and deaths
                """
                # Currently fit on alpha, a and b, r_dth,
                # & initial condition of exposed state and infected state
                #
                # RecoverHD corresponds to T_rh, the median time to recovery under hospitalization (assumed to be 15 days).
                # It is used to compute r_rh, the rate of recovery under hospitalization: r_rh = log(2)/T_rh 
                RecoverHD = 15  # Recovery Time when Hospitalized
                # VentilatedD does not correspond to a parameter in DELPHI_Explainer.ph.
                # It is used to compute r_rv, the rate of recovery under ventilation (not mentioned in DELPHI_Explainer.ph). 
                VentilatedD = 10  # Recovery Time when Ventilated
                # Maximum timespan of prediction, defaulted to go to 06/30/2020
                maxT = (datetime(2020, 8, 31) - date_day_since100).days + 1
                p_v = 0.25  # Percentage of ventilated (not mentioned in DELPHI_Explainer.ph)
                p_d = 0.02  # Percentage of infection cases detected.
                p_h = 0.10  # Percentage of detected cases hospitalized
                
                """ Fit on Total Cases """
                t_cases = validcases["day_since100"].tolist() - validcases.loc[0, "day_since100"]
                validcases_nondeath = validcases["case_cnt"].tolist()
                validcases_death = validcases["death_cnt"].tolist()
                balance = validcases_nondeath[-1] / max(validcases_death[-1], 10) / 3
                fitcasesnd = validcases_nondeath
                fitcasesd = validcases_death
                GLOBAL_PARAMS_FIXED = (
                    N, PopulationCI, PopulationR, PopulationD, PopulationI, p_d, p_h, p_v, day_increase, increase, transition2
                )
                
                def distancing_cspline_increase(par_time, par_days, limit, day_increase, increase, transition2):
                    transition1 = 2
                    if par_time <= par_days - transition1:
                        return 1.0
                    elif par_time < par_days + transition1:
                        par = (par_time - par_days) / transition1
                        return limit + (1.0 - limit) * 0.5 * (1.0 + (0.5 * par**3 - 1.5 * par))
                    elif par_time < day_increase - transition2:
                        return limit
                    elif par_time < day_increase + transition2:
                        par = (par_time - day_increase) / transition2
                        return limit + (1.0 - limit) * increase * 0.5 *(1.0 - (0.5 * par**3 - 1.5 * par)) 
                    else:
                        return limit + (1.0 - limit) * increase
                
                def nolockdown(par_time, par_days, limit, day_increase, increase, transition2):
                    return 1.0

                def model_covid(
                        t, x, alpha, days, r_s, r_dth, p_dth, k1, k2
                ):
                    """
                    SEIR + Undetected, Deaths, Hospitalized, corrected with ArcTan response curve
                    alpha: Infection rate
                    days: Median day of action
                    r_s: Median rate of action
                    p_dth: Mortality rate
                    k1: Internal parameter 1
                    k2: Internal parameter 2
                    y = [0 S, 1 E,  2 I, 3 AR,   4 DHR,  5 DQR, 6 AD,
                    7 DHD, 8 DQD, 9 R, 10 D, 11 TH, 12 DVR,13 DVD, 14 DD, 15 DT]
                    """
                    r_i = np.log(2) / IncubeD  # Rate of infection leaving incubation phase
                    r_d = np.log(2) / DetectD  # Rate of detection
                    r_ri = np.log(2) / RecoverID  # Rate of recovery not under infection
                    r_rh = np.log(2) / RecoverHD  # Rate of recovery under hospitalization
                    r_rv = np.log(2) / VentilatedD  # Rate of recovery under ventilation
                    gamma_t = nolockdown(t, days, r_s, day_increase, increase, transition2)
                    assert len(x) == 16, f"Too many input variables, got {len(x)}, expected 16"
                    S, E, I, AR, DHR, DQR, AD, DHD, DQD, R, D, TH, DVR, DVD, DD, DT = x
                    # Equations on main variables
                    dSdt = -alpha * gamma_t * S * I / N
                    dEdt = alpha * gamma_t * S * I / N - r_i * E
                    dIdt = r_i * E - r_d * I
                    dARdt = r_d * (1 - p_dth) * (1 - p_d) * I - r_ri * AR
                    dDHRdt = r_d * (1 - p_dth) * p_d * p_h * I - r_rh * DHR
                    dDQRdt = r_d * (1 - p_dth) * p_d * (1 - p_h) * I - r_ri * DQR
                    dADdt = r_d * p_dth * (1 - p_d) * I - r_dth * AD
                    dDHDdt = r_d * p_dth * p_d * p_h * I - r_dth * DHD
                    dDQDdt = r_d * p_dth * p_d * (1 - p_h) * I - r_dth * DQD
                    dRdt = r_ri * (AR + DQR) + r_rh * DHR
                    dDdt = r_dth * (AD + DQD + DHD)
                    # Helper states (usually important for some kind of output)
                    dTHdt = r_d * p_d * p_h * I
                    dDVRdt = r_d * (1 - p_dth) * p_d * p_h * p_v * I - r_rv * DVR
                    dDVDdt = r_d * p_dth * p_d * p_h * p_v * I - r_dth * DVD
                    dDDdt = r_dth * (DHD + DQD)
                    dDTdt = r_d * p_d * I
                    return [
                        dSdt, dEdt, dIdt, dARdt, dDHRdt, dDQRdt, dADdt, dDHDdt, dDQDdt,
                        dRdt, dDdt, dTHdt, dDVRdt, dDVDdt, dDDdt, dDTdt
                    ]

                def residuals_totalcases(params):
                    """
                    Wanted to start with solve_ivp because figures will be faster to debug
                    params: (alpha, days, r_s, r_dth, p_dth, k1, k2), fitted parameters of the model
                    """
                    # Variables Initialization for the ODE system
                    alpha, days, r_s, r_dth, p_dth, k1, k2 = params
                    params = max(alpha, 0), days, max(r_s, 0), max(r_dth, 0), max(min(p_dth, 1), 0), max(k1, 0), max(k2, 0)
                    x_0_cases = get_initial_conditions(
                        params_fitted=params,
                        global_params_fixed=GLOBAL_PARAMS_FIXED
                    )
                    x_sol = solve_ivp(
                        fun=model_covid,
                        y0=x_0_cases,
                        t_span=[t_cases[0], t_cases[-1]],
                        t_eval=t_cases,
                        args=tuple(params),
                    ).y
                    weights = list(range(1, len(fitcasesnd) + 1))
                    residuals_value = sum(
                        np.multiply((x_sol[15, :] - fitcasesnd) ** 2, weights)
                        + balance * balance * np.multiply((x_sol[14, :] - fitcasesd) ** 2, weights)
                    )
                    return residuals_value
                
    #            if step == 0 and transition2 == 7:
    #                best_params = minimize(
    #                    residuals_totalcases,
    #                    parameter_list,
    #                    method='trust-constr',  # Can't use Nelder-Mead if I want to put bounds on the params
    #                    bounds=bounds_params
    #                ).x  
    #                best_params = dual_annealing(
    #                    residuals_totalcases,
    #                    bounds_params
    #                ).x
    
                # Read parameters from Output_Manila_parameters.csv file.
                if os.path.exists(f"Output_Manila_parameters.csv"):
                    oldparameters = pd.read_csv(
                        f"Output_Manila_parameters.csv"
                    )
                    best_params = [
                        oldparameters.loc[0, "Infection Rate"],
                        oldparameters.loc[0, "Median Day of Action"],
                        oldparameters.loc[0, "Rate of Action"],
                        oldparameters.loc[0, "Rate of Death"],
                        oldparameters.loc[0, "Mortality Rate"],
                        oldparameters.loc[0, "Internal Parameter 1"],
                        oldparameters.loc[0, "Internal Parameter 2"]
                    ]
                    # Print parameters from Output_Manila_parameters.csv file.
                    print("Parameters from Output_Manila_parameters.csv file.")
                    print(best_params)
                    print("\n")
                else:
                    print("No Output_Manila_parameters.csv available!\n")
                
                t_predictions = [i for i in range(maxT)]

                def solve_best_params_and_predict(optimal_params):
                    # Variables Initialization for the ODE system
                    x_0_cases = get_initial_conditions(
                        params_fitted=optimal_params,
                        global_params_fixed=GLOBAL_PARAMS_FIXED
                    )
                    x_sol_best = solve_ivp(
                        fun=model_covid,
                        y0=x_0_cases,
                        t_span=[t_predictions[0], t_predictions[-1]],
                        t_eval=t_predictions,
                        args=tuple(optimal_params),
                    ).y
                    return x_sol_best

                x_sol_final = solve_best_params_and_predict(best_params)
                data_creator = DELPHIDataCreator(
                    x_sol_final=x_sol_final, date_day_since100=date_day_since100, best_params=best_params,
                    continent=continent, country=country, province=province,
                )
                # Creating the parameters dataset for this (Continent, Country, Province)
                mape_data = (
                                    mape(fitcasesnd, x_sol_final[15, :len(fitcasesnd)]) +
                                    mape(fitcasesd, x_sol_final[14, :len(fitcasesd)])
                            ) / 2
                df_parameters_cont_country_prov = data_creator.create_dataset_parameters(mape_data)
                list_df_global_parameters.append(df_parameters_cont_country_prov)
                # Creating the datasets for predictions of this (Continent, Country, Province)
                df_predictions_since_today_cont_country_prov, df_predictions_since_100_cont_country_prov = (
                    data_creator.create_datasets_predictions()
                )
                list_df_global_predictions_since_today.append(df_predictions_since_today_cont_country_prov)
                list_df_global_predictions_since_100_cases.append(df_predictions_since_100_cont_country_prov)
                print(f"Finished predicting for Continent={continent}, Country={country} and Province={province}.\n")
    #            print(list_df_global_predictions_since_100_cases)
    #            print(type(list_df_global_predictions_since_100_cases))
    #            print(df_parameters_cont_country_prov)
            else:  # len(validcases) <= 7
                print(f"Not enough historical data (less than a week)" +
                      f"for Continent={continent}, Country={country} and Province={province}")
                continue
        else:  # file for that tuple (country, province) doesn't exist in processed files
            continue

        # Output of modeling data and parameters.
        def write_output_file(filename, data_list):
            for line in data_list:
        #        print(line)
                line.to_csv(filename)

        print("Writing output files.\n")

    #    write_output_file("Output_Manila_step" + str(step) + "_sincetoday.csv", list_df_global_predictions_since_today)
        if step == 0 and transition2 == 15:
#            write_output_file("Output_Manila_nolockdown_parameters.csv", list_df_global_parameters)
            write_output_file("Output_Manila_nolockdown_since100.csv", list_df_global_predictions_since_100_cases)
            #print(list_df_global_parameters[0])
            parlist = list_df_global_parameters[0].to_numpy()
            alpha = parlist[[0], [5]].astype(float)
            days = parlist[[0], [6]].astype(float)
            r_s = parlist[[0], [7]].astype(float)
            r_d = np.log(2) / DetectD  # Rate of detection
            print(f"Infection Rate: %f" % (alpha))
            print(f"Median Day of Action: %f" % (days))
            print(f"Rate of Action: %f" % (r_s))
            print(f"Rate of Detection: %f\n" % (r_d))
            fag = open("Output_Manila_nolockdown_R.csv", "w")
            fag.write("day_since100,gamma(t),alpha*gamma(t),R(t)=alpha*gamma(t)/r_d\n")
            t = 0
            while t < maxT:
                gamma_t = nolockdown(t, days, r_s, day_increase, increase, transition2)
                alphagamma = alpha * gamma_t
                R = alphagamma / r_d
                fag.write(f"%d,%f,%f,%f\n" % (t,gamma_t,alphagamma,R))
                t += 1
            fag.close()
